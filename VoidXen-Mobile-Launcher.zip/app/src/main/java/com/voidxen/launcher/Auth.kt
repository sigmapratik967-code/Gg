package com.voidxen.launcher

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Optional backend (authApiUrl, https): verifies the social login and returns YOUR session token.
 * POST JSON {"action":"google"|"discord"|"guest","nickname":"..", + idToken / accessToken+discordId / guestId}
 * Response {"ok":true,"token":"..","nickname":"..","balance":"123"} or {"ok":false,"error":".."}
 */
object Auth {
    data class Result(val ok: Boolean, val token: String, val nickname: String, val balance: String, val error: String)

    fun post(url: String, body: JSONObject): Result {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("User-Agent", "VoidXenLauncher/1.0")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            val o = try {
                JSONObject(text)
            } catch (e: Exception) {
                return Result(false, "", "", "", "Invalid server response (HTTP $code)")
            }
            return Result(
                o.optBoolean("ok", false),
                o.optString("token", ""),
                o.optString("nickname", ""),
                o.optString("balance", ""),
                o.optString("error", "")
            )
        } finally {
            c.disconnect()
        }
    }

    /** Discord asks Discord itself who owns this access token (id, display name). */
    fun discordProfile(accessToken: String): Pair<String, String> {
        val c = URL("https://discord.com/api/users/@me").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Authorization", "Bearer $accessToken")
            c.setRequestProperty("User-Agent", "VoidXenLauncher/1.0")
            if (c.responseCode !in 200..299) throw IOException("Discord HTTP ${c.responseCode}")
            val o = JSONObject(String(c.inputStream.use { it.readBytes() }, Charsets.UTF_8))
            val name = o.optString("global_name", "").ifBlank { o.optString("username", "") }
            return Pair(o.optString("id", ""), name)
        } finally {
            c.disconnect()
        }
    }
}
