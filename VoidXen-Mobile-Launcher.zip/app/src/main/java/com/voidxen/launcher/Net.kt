package com.voidxen.launcher

import org.json.JSONObject
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder

data class Status(val online: Boolean, val players: Int?, val max: Int?)

object Net {
    /** Dropbox share link (dl=0) ko direct download link (dl=1) bana deta hai. */
    fun normalize(u: String): String {
        var s = u.trim()
        if (s.contains("dropbox.com")) {
            s = s.replace("dl=0", "dl=1")
            if (!s.contains("dl=1") && !s.contains("raw=1")) s += if (s.contains("?")) "&dl=1" else "?dl=1"
        }
        return s
    }

    /** Redirects khud follow karta hai taaki Range header har hop par sahi jaye. */
    fun open(start: String, rangeFrom: Long = 0L): HttpURLConnection {
        var url = normalize(start)
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "VoidXenLauncher/1.0")
            c.setRequestProperty("Accept-Encoding", "identity")
            if (rangeFrom > 0) c.setRequestProperty("Range", "bytes=$rangeFrom-")
            val code = c.responseCode
            if (code in 300..399 && code != 304) {
                val loc = c.getHeaderField("Location") ?: throw IOException("Redirect without Location")
                url = URL(URL(url), loc).toString()
                c.disconnect()
            } else {
                return c
            }
        }
        throw IOException("Too many redirects")
    }

    fun getText(u: String): String {
        val c = open(u)
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return String(c.inputStream.use { it.readBytes() }, Charsets.UTF_8)
        } finally {
            c.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

/** Real server status: statusUrl (JSON API) ya SAMP UDP query. Kuch nahi mila to null (unknown). */
object StatusRepo {

    fun fetch(s: ServerCfg): Status? {
        return try {
            when {
                s.statusUrl.isNotBlank() -> fromApi(s.statusUrl)
                s.ip.isNotBlank() && s.port > 0 -> sampQuery(s.ip, s.port)
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }

    // API JSON keys: players|online|count , maxplayers|maxonline|max , status
    private fun fromApi(url: String): Status {
        val o = JSONObject(Net.getText(url))
        fun int(vararg keys: String): Int? {
            for (k in keys) {
                if (o.has(k)) {
                    val v = o.optString(k, "").trim().toIntOrNull()
                    if (v != null) return v
                }
            }
            return null
        }
        val flag = if (o.has("status")) {
            val st = o.optString("status")
            st.equals("true", true) || st.equals("online", true) || st == "1"
        } else true
        return Status(flag, int("players", "online", "count"), int("maxplayers", "maxonline", "max"))
    }

    // Public SA-MP query protocol ('i' = server info)
    private fun sampQuery(host: String, port: Int): Status {
        val addr = InetAddress.getByName(host)
        val ip = addr.address
        if (ip.size != 4) return Status(false, null, null)
        val req = ByteArray(11)
        "SAMP".toByteArray(Charsets.US_ASCII).copyInto(req)
        ip.copyInto(req, 4)
        req[8] = (port and 0xFF).toByte()
        req[9] = ((port shr 8) and 0xFF).toByte()
        req[10] = 'i'.code.toByte()
        return DatagramSocket().use { sock ->
            sock.soTimeout = 3000
            sock.send(DatagramPacket(req, req.size, addr, port))
            val buf = ByteArray(1024)
            val p = DatagramPacket(buf, buf.size)
            try {
                sock.receive(p)
                if (p.length < 16) {
                    Status(true, null, null)
                } else {
                    val players = (buf[12].toInt() and 0xFF) or ((buf[13].toInt() and 0xFF) shl 8)
                    val max = (buf[14].toInt() and 0xFF) or ((buf[15].toInt() and 0xFF) shl 8)
                    Status(true, players, max)
                }
            } catch (e: SocketTimeoutException) {
                Status(false, null, null)
            }
        }
    }
}
