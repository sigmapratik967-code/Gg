package com.voidxen.launcher

import android.content.SharedPreferences
import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Device-local accounts (used when no authApiUrl server is configured). Passwords are salted + hashed, never stored. */
object LocalAccounts {
    private const val KEY = "local_accounts"

    private fun load(p: SharedPreferences): JSONObject =
        try { JSONObject(p.getString(KEY, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun hash(pw: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pw.toCharArray(), salt, 20000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
    }

    /** false if the email is already registered */
    fun register(p: SharedPreferences, email: String, pw: String): Boolean {
        val all = load(p)
        val k = email.lowercase()
        if (all.has(k)) return false
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        all.put(k, JSONObject().put("salt", Base64.encodeToString(salt, Base64.NO_WRAP)).put("hash", hash(pw, salt)))
        p.edit().putString(KEY, all.toString()).apply()
        return true
    }

    fun verify(p: SharedPreferences, email: String, pw: String): Boolean {
        val o = load(p).optJSONObject(email.lowercase()) ?: return false
        val salt = Base64.decode(o.optString("salt"), Base64.NO_WRAP)
        return MessageDigest.isEqual(hash(pw, salt).toByteArray(), o.optString("hash").toByteArray())
    }
}
