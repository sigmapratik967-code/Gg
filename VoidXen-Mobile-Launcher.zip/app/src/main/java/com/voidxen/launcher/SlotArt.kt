package com.voidxen.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View

/** Glass dome + platform + silhouette for one character slot (empty = create, filled = existing). */
class SlotArt(ctx: Context) : View(ctx) {
    var filled = false
        set(v) { field = v; invalidate() }
    var female = false
        set(v) { field = v; invalidate() }

    private val domeLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0x66FFFFFF; strokeWidth = 3f }
    private val domeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x14FFFFFF }
    private val platOuter = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE62A2338.toInt() }
    private val platInner = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xB3463E5E.toInt() }
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f }
    private val plus = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); strokeWidth = 7f; strokeCap = Paint.Cap.ROUND }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        c.drawOval(RectF(w * 0.02f, h * 0.84f, w * 0.98f, h * 0.99f), platOuter)
        c.drawOval(RectF(w * 0.14f, h * 0.87f, w * 0.86f, h * 0.96f), platInner)

        val r = w * 0.40f
        val top = h * 0.28f
        val dome = Path()
        dome.moveTo(cx - r, h * 0.90f)
        dome.lineTo(cx - r, top)
        dome.arcTo(RectF(cx - r, top - r, cx + r, top + r), 180f, 180f)
        dome.lineTo(cx + r, h * 0.90f)
        c.drawPath(dome, domeFill)
        c.drawPath(dome, domeLine)

        val baseY = h * 0.855f
        val figH = h * 0.56f
        val headR = figH * 0.085f
        val headY = baseY - figH + headR
        val torsoTop = headY + headR * 1.5f
        val torsoBottom = baseY - figH * 0.43f
        val tw = figH * (if (female) 0.17f else 0.22f)
        body.color = if (filled) 0xFFB07CFF.toInt() else 0xFF1D1830.toInt()
        edge.color = if (filled) 0xFFF7CA2A.toInt() else 0x80FFFFFF.toInt()
        if (filled) {
            glow.color = 0x55CA6FFD
            c.drawCircle(cx, baseY - figH * 0.5f, figH * 0.55f, glow)
        }
        val figure = Path()
        figure.addCircle(cx, headY, headR, Path.Direction.CW)
        figure.addRoundRect(RectF(cx - tw, torsoTop, cx + tw, torsoBottom), 14f, 14f, Path.Direction.CW)
        if (female) {
            figure.moveTo(cx - tw, torsoBottom - 4f)
            figure.lineTo(cx + tw, torsoBottom - 4f)
            figure.lineTo(cx + tw * 1.6f, baseY - figH * 0.16f)
            figure.lineTo(cx - tw * 1.6f, baseY - figH * 0.16f)
            figure.close()
            figure.addRect(RectF(cx - tw * 0.55f, baseY - figH * 0.16f, cx - tw * 0.1f, baseY), Path.Direction.CW)
            figure.addRect(RectF(cx + tw * 0.1f, baseY - figH * 0.16f, cx + tw * 0.55f, baseY), Path.Direction.CW)
        } else {
            figure.addRect(RectF(cx - tw * 0.92f, torsoBottom - 2f, cx - tw * 0.08f, baseY), Path.Direction.CW)
            figure.addRect(RectF(cx + tw * 0.08f, torsoBottom - 2f, cx + tw * 0.92f, baseY), Path.Direction.CW)
        }
        figure.addRoundRect(RectF(cx - tw - figH * 0.07f, torsoTop + 6f, cx - tw, torsoBottom - figH * 0.05f), 10f, 10f, Path.Direction.CW)
        figure.addRoundRect(RectF(cx + tw, torsoTop + 6f, cx + tw + figH * 0.07f, torsoBottom - figH * 0.05f), 10f, 10f, Path.Direction.CW)
        c.drawPath(figure, body)
        c.drawPath(figure, edge)
        if (!filled) {
            val py = headY - headR * 0.2f
            val s = w * 0.07f
            c.drawLine(cx - s, py, cx + s, py, plus)
            c.drawLine(cx, py - s, cx, py + s, plus)
        }
    }
}
