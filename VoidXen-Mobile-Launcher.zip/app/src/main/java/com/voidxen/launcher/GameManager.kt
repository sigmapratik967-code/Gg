package com.voidxen.launcher

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

class DownloadCancelled : Exception()

object GameManager {
    fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "game")

    fun serverDir(ctx: Context, s: ServerCfg): File =
        File(root(ctx), s.name.replace(Regex("[^A-Za-z0-9_-]"), "_"))

    fun localFile(ctx: Context, s: ServerCfg): File =
        File(serverDir(ctx, s), s.downloadFile.ifBlank { "game.bin" })

    fun dataDir(ctx: Context, s: ServerCfg): File = File(serverDir(ctx, s), "data")

    fun isApk(s: ServerCfg): Boolean = s.downloadFile.endsWith(".apk", ignoreCase = true)

    fun clearAll(ctx: Context) {
        root(ctx).deleteRecursively()
    }

    /** Zip extract (zip-slip safe). */
    fun unzip(zip: File, outDir: File) {
        outDir.mkdirs()
        val base = outDir.canonicalPath + File.separator
        ZipInputStream(FileInputStream(zip).buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(outDir, e.name)
                if (!f.canonicalPath.startsWith(base)) throw IOException("Unsafe zip entry")
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { out -> zin.copyTo(out) }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
    }
}

object Downloader {

    /**
     * Resumable download: pehle .part file me likhta hai, Range se resume karta hai,
     * SHA-256 (agar config me ho) se validate karta hai, phir final naam par rename.
     */
    fun download(
        url: String,
        dest: File,
        sha256: String,
        cancel: AtomicBoolean,
        onProgress: (done: Long, total: Long) -> Unit
    ) {
        val dir = dest.parentFile ?: throw IOException("Invalid path")
        dir.mkdirs()
        val part = File(dir, dest.name + ".part")
        var existing = if (part.exists()) part.length() else 0L

        var c = Net.open(url, existing)
        try {
            var code = c.responseCode
            if (code == 416) {            // stale/complete partial -> restart
                part.delete()
                existing = 0L
                c.disconnect()
                c = Net.open(url, 0L)
                code = c.responseCode
            }
            if (code != 200 && code != 206) throw IOException("Server HTTP $code")

            val append = code == 206 && existing > 0
            if (!append) {
                existing = 0L
                if (part.exists()) part.delete()
            }
            val len = c.contentLengthLong
            val total = if (len > 0) existing + len else -1L
            if (total > 0 && dir.usableSpace < (total - existing) + 10L * 1024 * 1024) {
                throw IOException("Storage kam hai")
            }

            c.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = existing
                    var last = 0L
                    while (true) {
                        if (cancel.get()) throw DownloadCancelled()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 250) {
                            last = now
                            onProgress(done, total)
                        }
                    }
                    onProgress(done, total)
                }
            }
            if (total > 0 && part.length() != total) throw IOException("File adhoori download hui")
        } finally {
            c.disconnect()
        }

        if (sha256.isNotBlank()) {
            val actual = sha256Of(part)
            if (!actual.equals(sha256.trim(), ignoreCase = true)) {
                part.delete()
                throw IOException("File validation fail (SHA-256 match nahi hua)")
            }
        }
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IOException("File save nahi hui")
    }

    private fun sha256Of(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
