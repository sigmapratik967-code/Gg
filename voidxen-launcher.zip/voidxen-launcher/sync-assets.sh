#!/usr/bin/env bash
# Launcher UI + config ko Android assets mein copy karta hai
set -e
cd "$(dirname "$0")"
mkdir -p android/app/src/main/assets/config
cp index.html android/app/src/main/assets/index.html
cp config/servers.json config/update.json android/app/src/main/assets/config/
echo "Assets synced -> android/app/src/main/assets/"
