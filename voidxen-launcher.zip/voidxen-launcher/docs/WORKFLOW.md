# Workflow — from code to a working launcher

Follow these phases in order. Each one has a check you can run before moving on.

```
[1] Set the server IP   →  [2] Build the APK   →  [3] Verify live status
        ↓                                              ↓
[6] Voice (LiveKit)  ←  [5] Payments (Razorpay)  ←  [4] Characters
        ↓
[7] Release + auto-update  →  [8] CI on GitHub
```

---

## Phase 1 — Set the server IP

Two places, same values:

```
config/servers.json                 (source of truth)
android/app/src/main/assets/config/servers.json   (copied by ./sync-assets.sh)
```

```json
"servers": [
  {
    "id": "vx-01",
    "name": "VoidXen Roleplay",
    "host": "188.127.241.74",
    "port": 1457,
    "region": "IN",
    "maxPlayers": 1000,
    "statusEndpoint": ""
  }
]
```

Rules:
- `host` = IP or domain only. No `http://`, no `:1457` inside it.
- `port` = number, no quotes.
- Keep `id` stable — character slots are stored under it.
- Adding a server: add another `{ ... }` object with a comma between.

**Check:** open `index.html` in a browser (or `python3 -m http.server 8080`). The card must show `188.127.241.74:1457`.

---

## Phase 2 — Build the APK

```bash
./sync-assets.sh                  # UI + config → android/app/src/main/assets
cd android
./gradlew assembleDebug           # needs JDK 17 + Android SDK 34
# output: android/app/build/outputs/apk/debug/app-debug.apk
```

Install on the phone:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The app opens in landscape. First launch asks for nothing except mic permission later.

**Check:** the launcher loads, the rail (Servers / Store / Voice / Settings) works, your server card appears.

---

## Phase 3 — Verify the live status

The status is a real check, not a mock:

| Path | How it checks | Accuracy |
|---|---|---|
| Android app | `VoidXen.probe(host, port)` opens a TCP socket | exact |
| `statusEndpoint` | your API returns `{online, ping, players}` | exact + player count |
| Browser | HTTP request to `host:port` | approximate |

If the card says **OFFLINE** on the phone while the game server is running:

1. Is the port reachable from mobile data? Try a different network (Wi-Fi vs 4G).
2. Firewall / hosting panel: allow inbound TCP on `1457`.
3. Is the game server process actually listening on that IP? Check with
   `ss -lntp | grep 1457` on the server.
4. Test from the phone browser: `http://188.127.241.74:1457` — if nothing answers,
   the port is closed or filtered, and no launcher can fix that.

Optional but recommended — live player counts:

```json
"statusEndpoint": "https://api.yoursite.com/servers/vx-01"
```

```js
// server side
{ "online": true, "ping": 38, "players": 842 }
```

**Check:** stop the game server → card turns OFFLINE on the next refresh. Start it → ONLINE.

---

## Phase 4 — Characters (3 slots)

Currently slots live on the device (`localStorage`, key `vx_slots`). Fine for a single phone,
lost when the app data is cleared.

To make them account-wide:

1. Backend endpoints: `GET /characters`, `POST /characters`, `DELETE /characters/:id`.
2. In `index.html`, replace `slotsOf()` reads with a fetch on login and cache the result.
3. Save on `cCreate` (POST) and on `connectTo` (PATCH last-played).

**Check:** create a character on slot 2 → close app → reopen → it is still there.

---

## Phase 5 — Payments (real money, INR)

1. Razorpay dashboard → **API Keys** → copy the **Key ID** (`rzp_live_...` or `rzp_test_...`).
   Never copy the key secret into the app.
2. In the launcher: **Settings → Payments** → paste Key ID + your verify URL → SAVE.
3. Backend verify endpoint (Node):

```js
import crypto from 'node:crypto';
import express from 'express';
const app = express();
app.use(express.json());

app.post('/pay/verify', (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, item } = req.body;
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(`${razorpay_order_id}|${razorpay_payment_id}`)
    .digest('hex');

  if (expected !== razorpay_signature) return res.status(400).json({ ok: false, error: 'bad signature' });

  // grant the entitlement to this user in your DB
  res.json({ ok: true });
});

app.listen(8080);
```

4. The app unlocks Voice / VIP only after `{ ok: true }` comes back.

Notes:
- For Google Play distribution of digital goods, Play Billing is the compliant route; Razorpay suits direct APK distribution.
- Test with `rzp_test_` keys and Razorpay's test cards first.

**Check:** buy Voice Chat Lifetime with a test card → Voice screen flips from LOCKED to UNLOCKED.

---

## Phase 6 — Voice chat (multi-user)

The app already captures the mic, shows the level meter and handles push-to-talk. It needs a
signaling server for real conversations.

LiveKit (shortest path):

```bash
docker run --rm -p 7880:7880 -p 7881:7881 -p 7882:7882/udp \
  livekit/livekit-server --dev --bind 0.0.0.0
```

1. Put the URL in the config: `"voice": { "signalingUrl": "wss://your-host:7880" }`.
2. Backend mints an access token (API key + secret, server-side only).
3. In `index.html`, after `startMic()`:

```js
const room = new LiveKitClient.Room();
await room.connect(cfg.voice.signalingUrl, token);
await room.localParticipant.publishTrack(micStream.getAudioTracks()[0]);
room.on('trackSubscribed', (track) => {
  const el = document.createElement('audio');
  el.autoplay = true;
  track.attach(el);
  document.body.appendChild(el);
});
```

**Check:** two phones join the same channel and hear each other.

---

## Phase 7 — Release and auto-update

1. Bump the version in `index.html` (`APP_VERSION`) and in `android/app/build.gradle.kts`.
2. Build the release APK, upload it somewhere public.
3. Update the manifest on your host:

```json
{ "version": "1.2.0", "notes": "Live status fix", "apk": "https://.../voidxen-1.2.0.apk", "force": false }
```

4. Paste that URL in **Settings → Update**. The launcher compares versions on every start.

**Check:** set the manifest to a higher version → reopen the app → update toast appears.

---

## Phase 8 — CI on GitHub

`.github/workflows/build-apk.yml` builds a debug APK on every push and uploads it as an artifact.

To also publish releases, add a tag:

```bash
git tag v1.2.0 && git push origin v1.2.0
```

The workflow attaches the APK to the GitHub Release automatically.

**Requirement:** the workflow needs a repository with write access for the Actions token.
If your app installation is read-only, push the repo manually once with write access, then CI works.

---

## Quick checklist

| # | Task | Done when |
|---|---|---|
| 1 | IP + port in `config/servers.json` | card shows `IP:port` |
| 2 | `./sync-assets.sh` + `assembleDebug` | APK installs, opens in landscape |
| 3 | Live status | stopping the game server flips the card to OFFLINE |
| 4 | 3 character slots | create on slot 2, reopen, still there |
| 5 | Razorpay key + verify endpoint | test purchase unlocks Voice |
| 6 | LiveKit URL + token | two phones hear each other |
| 7 | `update.json` hosted + URL set | update toast on version bump |
| 8 | GitHub Actions | APK artifact appears on push |

---

## Common problems

| Symptom | Cause | Fix |
|---|---|---|
| Card always OFFLINE | port closed / filtered | open TCP `1457` in the firewall, test from mobile data |
| Config edit does nothing | `localStorage` copy wins over the file | Settings → Config file → RESET TO DEFAULT, or edit inside the app |
| Voice screen stays LOCKED | purchase not verified | check the verify endpoint returns `{ok:true}` |
| Characters vanished | server `id` changed | keep `id` stable, or migrate `vx_slots` keys |
| APK build fails | wrong JDK | use JDK 17, Android SDK 34 |
| Update never shows | manifest version not higher | `version` must be greater than `APP_VERSION` |
