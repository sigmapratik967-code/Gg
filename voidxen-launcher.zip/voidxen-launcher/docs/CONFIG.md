# Config Guide

## 1. `config/servers.json`

One file holds everything: servers, client launch settings, voice, payments and the update URL.

```json
{
  "version": "1.1.0",
  "updateUrl": "https://example.com/voidxen/update.json",
  "client": {
    "package": "com.voidxen.client",
    "connectFormat": "{host}:{port}",
    "scheme": "voidxen"
  },
  "voice": { "signalingUrl": "wss://voice.example.com", "room": "global" },
  "payments": { "keyId": "rzp_test_xxxxxxxx", "verifyUrl": "https://api.example.com/pay/verify", "currency": "INR" },
  "servers": [
    {
      "id": "vx-01",
      "name": "VoidXen Roleplay",
      "host": "203.0.113.10",
      "port": 7777,
      "region": "IN",
      "maxPlayers": 300,
      "statusEndpoint": "https://api.example.com/servers/vx-01"
    }
  ]
}
```

| Field | Meaning |
|---|---|
| `id` | Unique server id. Character slots are stored under it — changing it resets those slots |
| `name` | Text on the server card |
| `host` | IP or domain — the IP half of IP:port |
| `port` | Game port (CR-MP default 7777) |
| `region` | Two-letter code shown on the card |
| `maxPlayers` | Player cap shown on the card |
| `statusEndpoint` | Optional. Your API returns `{ "online": true, "ping": 42, "players": 184 }` |

Adding a server = adding an object. Removing = deleting the object. Both also work in the app under
**Settings → Config file**.

## 2. Real online / offline detection

Order of checks:

1. **Android bridge** — `VoidXen.probe(host, port, timeoutMs)` opens a TCP socket. Response:
   `{"online":true,"ping":42}` or `{"online":false,"ping":null}`.
2. **`statusEndpoint`** — an HTTP JSON endpoint you control. Best accuracy, and the only way to show
   live player counts.
3. **Browser HTTP probe** — `fetch('http://host:port/')`. Closed port rejects → offline. Open port answers →
   reachable. Browsers cannot open raw TCP sockets, so treat this as an approximation.

Settings → Network controls the timeout (1 s / 2.5 s / 5 s), the auto-refresh interval
(10 s / 20 s / 60 s / 5 min) and whether the HTTP fallback is used.

### Status endpoint example

```json
GET https://api.example.com/servers/vx-01
{ "online": true, "ping": 42, "players": 184 }
```

A tiny Node implementation that opens a TCP socket to the game port:

```js
import net from 'node:net';
app.get('/servers/:id', (req, res) => {
  const s = SERVERS[req.params.id];
  const t0 = Date.now();
  const sock = net.connect({ host: s.host, port: s.port });
  sock.setTimeout(2500);
  sock.on('connect', () => { sock.destroy(); res.json({ online: true, ping: Date.now() - t0, players: s.players }); });
  sock.on('timeout', () => { sock.destroy(); res.json({ online: false, ping: null, players: 0 }); });
  sock.on('error', () => res.json({ online: false, ping: null, players: 0 }));
});
```

## 3. Changing IP:port

1. `config/servers.json` → `host` and `port`
2. In app: Settings → Config file → SAVE (stored in `localStorage`, wins over the file)
3. Remote: host the config yourself and load it at boot so every user gets the new IP at once

Priority: `localStorage` (saved in app) → `config/servers.json` → built-in defaults.
Settings → Config file → RESET TO DEFAULT clears the local copy.

## 4. Character slots

`localStorage` key `vx_slots`:

```json
{
  "vx-01": [
    { "name": "Ankit_Raxo", "gender": "male", "level": 0, "money": 250,
      "look": { "face": 50, "hair": 50, "build": 50, "skin": 50 } },
    null,
    null
  ]
}
```

For server-side characters, call your API in `openSlot()` / `connectTo()` and store the returned id
alongside the character.

## 5. Store and payments

Coins items use the in-game balance. Services use real money through Razorpay Checkout.

```
Settings → Payments → Key ID + verify endpoint
```

Flow:

1. App opens Razorpay Checkout with `amount = price * 100` (paise).
2. Razorpay returns `razorpay_payment_id`, `razorpay_order_id`, `razorpay_signature`.
3. App POSTs them to your `verifyUrl`.
4. Your server checks the HMAC signature with the key **secret** and answers `{ "ok": true }`.
5. Only then does the app unlock the item.

Never put the key secret in the app or the repo. For Google Play distribution, Play Billing is the
policy-compliant route for digital goods; Razorpay is fine for direct APK distribution.

## 6. Voice chat

What exists today: microphone capture, real-time level meter, push-to-talk, join/leave, channel UI.

For multi-user audio add a signaling layer. LiveKit is the shortest path:

```js
// after a verified purchase unlocks voice
const room = new LiveKitClient.Room();
await room.connect(cfg.voice.signalingUrl, tokenFromYourBackend);
await room.localParticipant.publishTrack(micStream.getAudioTracks()[0]);
room.on('trackSubscribed', (track) => {
  const el = document.createElement('audio');
  el.autoplay = true;
  track.attach(el);
  document.body.appendChild(el);
});
```

The access token must be minted by your backend with the API secret.

## 7. Android wrapper

- `MainActivity.kt` — landscape WebView, `VoidXen` JS bridge
- `assets/index.html` + `assets/config/*.json` — copied by `./sync-assets.sh`
- `AndroidManifest.xml` — `sensorLandscape`, mic + internet permissions, `<queries>` for the game package

Change the game package in three places: `client.package` in the config, the `<queries>` block in the
manifest, and the fallback deep-link scheme if you use one.

## 8. Update manifest

```json
{ "version": "1.1.1", "notes": "Changelog text", "apk": "https://.../app.apk", "force": false }
```

`APP_VERSION` in `index.html` is compared with `version`. Bump the app version when you ship a build.
