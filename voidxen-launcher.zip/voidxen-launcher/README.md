# VoidXen Mobile — Launcher

A landscape, HD game launcher for a CR-MP style 3D roleplay game. Every server gets **3 character slots**,
servers are added and removed through a **config file**, online/offline state is a **real connection check**,
and voice chat unlocks through a **real-money purchase**.

## What is in this repo

| Part | File |
|---|---|
| Launcher UI — single file, no dependencies | `index.html` |
| Server list, IP:port, client, voice, payment config | `config/servers.json` |
| Auto-update manifest | `config/update.json` |
| Android WebView wrapper (Kotlin, landscape) | `android/` |
| Config and payment guide | `docs/CONFIG.md` |
| Copy UI + config into the Android assets | `sync-assets.sh` |

## Run it

```bash
cd voidxen-launcher
python3 -m http.server 8080
# open http://localhost:8080
```

Opening `index.html` directly over `file://` works too. In that case the browser blocks reading
`config/servers.json`, so the built-in defaults are used until you save a config from Settings.

## Screens

- **Login / Register / Guest** — account is stored on the device (demo auth, replace with your API).
- **Servers** — live online/offline per server, ping, region, and 3 slot chips on every card.
- **Characters** — three pedestals per server. Tap an empty slot to create, a filled one to connect.
- **Create character** — gender, name, random name, face/hair/build/skin with a rotating 3D preview.
- **Store** — Services (real money, INR), Vehicles, Weapons, Clothing, Coins (real money top-up).
- **Voice** — locked until purchased; then mic meter, push-to-talk, channel join/leave.
- **Settings** — General, UI System, Graphics, Audio, Controls, Network, Config file, Payments, Update, Account.

## Real server status

A server is shown online only when the launcher can actually reach it:

1. **Android app** — `window.VoidXen.probe(host, port, timeout)` opens a real TCP socket
   (`MainActivity.kt` → `Bridge.probe`). This is the accurate path.
2. **Status endpoint** — optional `statusEndpoint` per server. Your API returns
   `{ "online": true, "ping": 42, "players": 184 }`.
3. **Browser fallback** — an HTTP request to `host:port`. A closed port rejects (offline), an open one answers
   (reachable). A browser cannot open raw TCP sockets, so the Android app is the real test.

The card shows which method answered (`via tcp` / `via api` / `via http`), and the check repeats on the
interval set in Settings → Network.

## Server add / remove

Edit `config/servers.json`:

```json
{
  "servers": [
    { "id": "vx-01", "name": "My Server", "host": "203.0.113.10", "port": 7777,
      "region": "IN", "maxPlayers": 200, "statusEndpoint": "" }
  ]
}
```

Or in the app: **Settings → Config file** → edit JSON → **SAVE**. **DOWNLOAD** exports a fresh
`servers.json` you can drop into the app assets. Delete an object to remove that server.

## 3 character slots

Slot data lives in `localStorage` under `vx_slots`, keyed by server `id`:

```json
{ "vx-01": [ { "name": "Ankit_Raxo", "level": 0, "money": 250 }, null, null ] }
```

Changing a server `id` gives it a fresh set of slots.

## Store and real money

- Coins items (vehicles, weapons, clothing) are bought with in-game coins.
- Services are paid in **INR** through Razorpay Checkout: Voice Chat Lifetime ₹199, Voice Chat Monthly ₹99,
  VIP ₹149, Name Change ₹49, plus coin top-ups.
- Add your **Key ID** in Settings → Payments. The key secret must never ship inside the app — the app posts the
  Razorpay response to your verify endpoint, and only a verified reply unlocks the item.

Without a key, pressing BUY explains exactly what is missing instead of pretending to charge.

## Voice chat

Purchasing a Voice plan unlocks the panel. The microphone, level meter and push-to-talk are real
(WebAudio). Multi-user audio needs a signaling server — LiveKit is the shortest path. Set
`voice.signalingUrl` in the config and publish your mic track to the room. See `docs/CONFIG.md`.

## Android build

```bash
./sync-assets.sh                 # copies index.html + config into android/app/src/main/assets
cd android
./gradlew assembleDebug
# android/app/build/outputs/apk/debug/app-debug.apk
```

The wrapper runs in landscape (`sensorLandscape`), loads the launcher from assets, and exposes the
`VoidXen` bridge: `launch(json)`, `probe(host, port, ms)`, `probeAsync(...)`, `version()`, `toast(msg)`.

Launch payload sent to the game client:

```json
{ "package": "com.voidxen.client", "address": "203.0.113.10:7777", "character": "Ankit_Raxo", "slot": 0,
  "graphics": { "quality": "High", "resolutionScale": 100, "fps": "90" },
  "audio": { "master": 80, "voice": 90 },
  "controls": { "sensitivity": 55, "invertY": false } }
```

## Auto-update

Host `config/update.json`, paste its URL in Settings → Update. The launcher compares versions on start
and on demand.

## Scope

This repo is the launcher, not the game. The 3D roleplay client (engine, map, vehicles) has to exist
separately — the launcher starts it with the server address, character and graphics settings.
