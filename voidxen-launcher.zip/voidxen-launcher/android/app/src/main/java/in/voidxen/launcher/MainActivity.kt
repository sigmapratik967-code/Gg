package in.voidxen.launcher

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.concurrent.thread

/**
 * VoidXen Mobile launcher — landscape WebView wrapper.
 *
 * JS bridge (window.VoidXen):
 *   launch(json)             -> opens the game client with address + settings
 *   probe(host, port, ms)    -> real TCP reachability check, returns JSON
 *   version()                -> launcher version
 *   toast(msg)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = "$userAgentString VoidXenLauncher/$LAUNCHER_VERSION"
        }

        web.addJavascriptInterface(Bridge(), "VoidXen")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.scheme == "http" || url.scheme == "https") {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, url)); true
                    } catch (e: Exception) { false }
                }
                return false
            }
        }

        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    inner class Bridge {

        /** Start the game client with address + graphics/audio/control settings. */
        @JavascriptInterface
        fun launch(payloadJson: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(payloadJson)
                    val pkg = o.optString("package", "com.voidxen.client")
                    val address = o.optString("address", "")
                    val character = o.optString("character", "")
                    val slot = o.optInt("slot", 0)

                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        setClassName(pkg, "$pkg.MainActivity")
                        putExtra("server_address", address)
                        putExtra("character_name", character)
                        putExtra("slot_index", slot)
                        o.optJSONObject("graphics")?.let { putExtra("graphics_json", it.toString()) }
                        o.optJSONObject("audio")?.let { putExtra("audio_json", it.toString()) }
                        o.optJSONObject("controls")?.let { putExtra("controls_json", it.toString()) }
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }

                    if (intent.resolveActivity(packageManager) != null) {
                        startActivity(intent)
                    } else {
                        val uri = Uri.parse("voidxen://connect?addr=" + Uri.encode(address) +
                                "&name=" + Uri.encode(character) + "&slot=" + slot)
                        val deep = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        if (deep.resolveActivity(packageManager) != null) {
                            startActivity(deep)
                        } else {
                            toast("Game client not installed ($pkg)")
                        }
                    }
                } catch (e: Exception) {
                    toast("Launch error: " + e.message)
                }
            }
        }

        /**
         * Real reachability check: opens a TCP socket to host:port.
         * Returns {"online":true,"ping":42} or {"online":false,"ping":null}.
         * This is what makes the online/offline state in the launcher real.
         */
        @JavascriptInterface
        fun probe(host: String, port: String, timeoutMs: Int): String {
            val portNum = port.toIntOrNull() ?: 0
            if (portNum <= 0) return "{\"online\":false,\"ping\":null,\"error\":\"bad port\"}"
            val started = System.currentTimeMillis()
            return try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, portNum), timeoutMs.coerceIn(500, 15000))
                    val ping = System.currentTimeMillis() - started
                    "{\"online\":true,\"ping\":$ping}"
                }
            } catch (e: Exception) {
                "{\"online\":false,\"ping\":null}"
            }
        }

        /** Async probe for the UI thread; result is posted back through a JS callback. */
        @JavascriptInterface
        fun probeAsync(host: String, port: String, timeoutMs: Int) {
            thread {
                val result = probe(host, port, timeoutMs)
                runOnUiThread {
                    web.evaluateJavascript(
                        "window.__vxProbeResult && window.__vxProbeResult('$host','$port',$result)",
                        null
                    )
                }
            }
        }

        @JavascriptInterface
        fun version(): String = LAUNCHER_VERSION

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    companion object {
        const val LAUNCHER_VERSION = "1.1.0"
    }
}
