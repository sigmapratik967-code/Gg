-keepclassmembers class in.voidxen.launcher.MainActivity$Bridge {
    public *;
}
